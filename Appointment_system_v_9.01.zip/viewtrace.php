<?PHP
//Version 9.0
//	Changes due to user SESSION consolidation
//Version 8.04a
//	Some reformatting
//Version 5.02b
//	Absorb duplicates
//Version 5.02a
//ini_set('display_errors', '1');

// Set up environment
require "environment.php";

$Errormessage = "";
// If the UserIndex has not been set as a session variable, the user needs to sign in
if (! isset($_SESSION["User"])) {
	header('Location: index.php'); // prevents direct access to this page (must sign in first).
	exit;
}

//Get POST variables if action requested
if ($_SERVER["REQUEST_METHOD"] == "POST") {
}

function logfile_print() {
	global $user_record;
	global $user_email;
	global $user_count;

	// open the trace file
	$raw_flag = false;
	$getanother = 0;
	$old_date = "";
	$last_entry = "";
	$last_entry_count = 0;
	$user_record = [];
	$user_email = [];
	$user_count = [];
	$logfile = fopen("appt_error_log", "r") or die("Unable to open file!");
	while (! feof($logfile) /* AND ($getanother < 500) */ ) {
		$event_entry = fgets($logfile);
		if (! $event_entry) continue;
		if (trim($event_entry) == "") continue;
		if (substr($event_entry, 0, 8) == "Warning:") continue;
		if ($event_entry == $last_entry) {
			$last_entry_count++;
			continue;
		}
		else {
			$last_entry_count = 0;
			$last_entry = $event_entry;
		}

		if (substr($event_entry, 0, 1) == "[") {
			if ($raw_flag) @$user_record[$event_user] .= "</span>";
			$raw_flag = false;
		}
		if ($raw_flag) {
			@$user_record[$event_user] .= "<br />$event_entry";
			continue;
		}

		$end_of_timestamp = strpos($event_entry, "]");
		$event_timestamp[0] = $event_timestamp[1] = "";
		$event_timestamp = explode(" ", substr($event_entry, 1, $end_of_timestamp - 2));
		$event = substr($event_entry, $end_of_timestamp + 1);
		if ($event_timestamp[0] != $old_date) {
			// Date changed, show all the data
			show_all();

			if ($old_date) {
				// Close yesterday's box
				echo "</div> <!-- " . $old_date . " -->";
			}

			// Start today's box
			$old_date = $event_timestamp[0];
			echo "\n\n<div class='trace_daybox' title='$old_date' onclick=\"Top$old_date.focus();\">";
			echo "\n<div id=\"Top$old_date\">$old_date</div>";

			// Clear yesterday's data
			$user_record = [];
			$user_count = [];
			$user_inet = [];
		}

		// Parse the new record
		if (strpos($event, "PHP ")) {
			@$user_record[$event_user] .= "\n<br /><span class='trace_errorbox' style='float: none;'>$event_timestamp[1]: $event";
			$raw_flag = true;
			continue;
		}
		$event_module = $event_user = $event_data = "";
		
		$colon_location = strpos($event, ":");
		$event_module = substr($event, 1, $colon_location - 1);
		$comma_location = strpos($event, ",");
		$event_user = trim(substr($event, $colon_location + 1, $comma_location - $colon_location - 1));
		if ($event_user == "SYSTEM") $event_user = "_SYSTEM_";
		$event_data = trim(substr($event, $comma_location + 1));
		if (! isset($user_count[$event_user])) $user_count[$event_user] = 0;
		//echo "\n<br />$event($event_module, $event_user, $event_data)"; // for debugging

		// Add the event to the user record
		switch ($event_module) {
		case "INDEX":
			// Show raw event
			//echo "\n<div class='userbox'>$event_timestamp[1] on $event_timestamp[0]";
			//echo "\n<br />$event_module<br />$event_user<br />$event_data</div>";
			if (strstr($event_data, "Login")) break;
			if (strstr($event_data, "using email")) {
				$email = substr($event_data, 12);
				$user_email[$email] = $event_user;
				$user_email[$event_user] = $email;
				break;
			}
			if (strstr($event_data, "logged in")) {
				$user_count[$event_user] = $user_count[$event_user] + 1;
				if (array_key_exists($event_user, $user_record)) {
					//show_box("userbox", $event_user, $user_record[$event_user]);
					//$user_record[$event_user . " (" . $user_count[$event_user] . ")"] = "\n<br />$event_timestamp[1]: [I] " . $user_record[$event_user];
					$user_email[$event_user . " (" . $user_count[$event_user] . ")"] = $user_email[$event_user];
				}
				$user_record[$event_user] = "";
				break;
			}
			@$user_record[$event_user] .= "\n<br />$event_timestamp[1]: [I] $event_data";
			break;
		case "APPT":
			if (strstr($event_data, "ViewUser")) {
				$user_inet[$email] = true;
				$user_inet[$event_user] = true;
			}
			@$user_record[$event_user] .= "\n<br />$event_timestamp[1]: [A] $event_data";
			break;
		case "EXPORT":
			@$user_record[$event_user] .= "\n<br />$event_timestamp[1]: [A] $event_data";
			break;
		case "MANAGE":
			@$user_record[$event_user] .= "\n<br />$event_timestamp[1]: [M] $event_data";
			break;
		case "CHGOPT":
			@$user_record[$event_user] .= "\n<br />$event_timestamp[1]: [C] $event_data";
			break;
		case "PATT":
			@$user_record[$event_user] .= "\n<br />$event_timestamp[1]: [P] $event_data";
			break;
		case "REMIND";
			if (strstr($event_data, "reminders ran")) $event_data = "Reminders ran";
			@$user_record["_SYSTEM_"] .= "\n<br />$event_timestamp[1]: $event_data";
			break;
		case "PHP Fatal error":
			echo "\n<div class='errorbox'>@$event_timestamp[1]: $event";
			$raw_flag = true;
			break;
		default:
			// Show raw event
			echo "\n<div class='errorbox'>@$event_timestamp[1]: $event</div>";
		}

		$getanother++;
	}

	// finish up
	show_all();
	echo "</div>";

	// close the trace file
	fclose($logfile);
}

function show_all() {
	global $user_record;
	asort($user_record);
	foreach ($user_record as $j => $e) {
		if ($j == "_SYSTEM_") {
			$class = 'trace_systembox';
		}
		else if (strstr($e, "[A]") AND strstr($e, "=ViewUser")) {
			$class = 'trace_inetbox';
		}
		else if (strstr($e, "[I]") AND strstr($e, "NewUser")) {
			$class = 'trace_inetbox';
		}
		else {
			$class = 'trace_userbox';
		}

		// Show the box
		show_box($class, $j, $e);
	}
}

function show_box($c, $j, $e) {
	global $user_record;
	global $user_email;

	echo "\n\n<div class=$c><center><b>$j";
	$m = @$user_email[$j];
	if ($m) echo " ($m)";
	echo "</b></center>" .  substr($e, 7) . "</div>";
}

?>

<!--================================================================================================================-->
<!DOCTYPE html>

<head>
<title>AARP Appointment Error Log</title>
<meta name=description content="AARP Appointments">
<link rel="SHORTCUT ICON" href="appt.ico">
<link rel="stylesheet" href="appt.css">
<script>
	/* ******************************************************************************************************************* */
	function Initialize() {
	/* ******************************************************************************************************************* */
	}
</script>
</head>
<!-- =================================================== WEB PAGE BODY ============================================ -->

<body onload="Initialize()">
<div id="Main">
	<div class="page_header">
		<h1>Tax-Aide Appointments Error Log</h1>
		<?php echo "You are signed in as " . str_replace("!", "&apos;", $_SESSION["User"]["user_full_name"]) . "\n"; ?>
	</div>
</div>

<div>
	<?php logfile_print(); ?>
</div>

<div id="trace_manage_box">
	<a href="sitemanage.php">
		<button id="trace_close_log_button">Close log</button>
	</a>
</div>

</body>
