<?php
// Version 5.00
// Required only for earlier installations
?>
