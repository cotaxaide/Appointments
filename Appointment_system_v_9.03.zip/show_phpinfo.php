<?php
require "environment.php";
phpinfo();
?>
